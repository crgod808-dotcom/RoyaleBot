// Ultra frontend script (improved)
// IMPORTANT: after download, set HF_API_URL to your Hugging Face Space predict endpoint or your proxy:
// e.g. const HF_API_URL = 'https://huggingface.co/spaces/RoyaleClasher/RoyaleBot/api/predict/';
const HF_API_URL = 'https://YOUR-HUGGINGFACE-SPACE_URL/api/predict/'; // <-- edit me

const chatWindow = document.getElementById('chat-window');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const chips = document.querySelectorAll('.chip');

function now(){ return new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); }
function mkNode(who, html){
  const el = document.createElement('div');
  el.className = 'msg ' + (who === 'user' ? 'user' : 'ai');
  const avatar = document.createElement('div'); avatar.className='avatar';
  const content = document.createElement('div'); content.className='content';
  const meta = document.createElement('div'); meta.className='meta'; meta.textContent = (who==='user'? 'You':'Assistant') + ' · ' + now();
  const text = document.createElement('div'); text.className='text'; text.innerHTML = html;
  const actions = document.createElement('div'); actions.className = 'actions';
  content.append(meta, text, actions);
  el.append(avatar, content);
  return el;
}
function appendMsg(who, html){ const n = mkNode(who, html); chatWindow.appendChild(n); chatWindow.scrollTop = chatWindow.scrollHeight; }

// render markdown safely using marked.js (loaded in index.html)
function renderMarkdown(md){ try{ return marked.parse(md); } catch(e){ return md; } }

// simple deck parser (extract card names)
function parseDeck(text){
  // very simple: split by commas and newlines, trim, remove empties
  const tokens = text.split(/,|\n/).map(t=>t.trim()).filter(Boolean);
  return tokens.slice(0, 12); // max 12
}

async function sendMessage(){
  const raw = userInput.value.trim(); if(!raw) return;
  // if user pasted a deck (detect commas + known card words), create structured prompt
  let prompt = raw;
  const isDeck = /,/.test(raw) && raw.split(',').length >= 4;
  if(isDeck){
    const cards = parseDeck(raw);
    prompt = `Analyze this deck and give: 1) win condition 2) weaknesses 3) suggested tech cards. Deck: ${cards.join(', ')}`;
  }

  appendMsg('user', renderMarkdown(raw));
  userInput.value = '';
  appendMsg('ai', '<em>Thinking...</em>');

  try{
    const response = await fetch(HF_API_URL, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({data: [prompt]})
    });
    const json = await response.json();
    // remove the temporary 'Thinking...' node (last AI message)
    const lastMsg = chatWindow.querySelectorAll('.msg.ai');
    if(lastMsg.length) lastMsg[lastMsg.length-1].remove();

    let text = '';
    if(json){
      if(json.data && Array.isArray(json.data)) text = Array.isArray(json.data[0]) ? json.data[0].join(' ') : json.data[0];
      else if(json.generated_text) text = json.generated_text;
      else text = JSON.stringify(json);
    }
    appendMsg('ai', renderMarkdown(text || "No response"));
  } catch(err){
    console.error(err);
    appendMsg('ai', '<strong>Error:</strong> could not reach AI. Check HF_API_URL.');
  }
}

sendBtn?.addEventListener('click', sendMessage);
userInput?.addEventListener('keydown', (e)=>{ if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); sendMessage(); } });
chips.forEach(c=> c.addEventListener('click', ()=> { userInput.value = c.textContent; userInput.focus(); }));

// initial welcome
appendMsg('ai', renderMarkdown('**Welcome!** I am your Clash Royale coach. Paste a deck or ask about cards.')) ;
