import pandas as pd

# Replace this with the exact name of your uploaded CSV
CLASH_ROYALE_CSV = "clash_wiki_clean.csv"

# Load the CSV
df = pd.read_csv(CLASH_ROYALE_CSV)

# Simple function to search for a keyword
def search_clash_info(query):
    # Convert query to lowercase for matching
    query = query.lower()
    # Filter rows where the title or content contains the query
    results = df[df['title'].str.lower().str.contains(query) | df['content'].str.lower().str.contains(query)]
    if results.empty:
        return None
    # Return first matching content
    return results.iloc[0]['content']