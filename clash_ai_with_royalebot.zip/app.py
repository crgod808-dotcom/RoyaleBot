import gradio as gr
from clashinfo import df
from RuleBook import CLASH_ROYALE_SYSTEM_MESSAGE
from huggingface_hub import InferenceClient

def search_wiki(query, top_k=3):
    """Find top_k rows in df most relevant to query (loose matching)"""
    query_words = query.lower().split()
    matches = []

    for _, row in df.iterrows():
        text = f"{row['title']} {row['content']}".lower()
        score = sum(word in text for word in query_words)
        if score > 0:
            matches.append((score, f"{row['title']}: {row['content']}"))

    # Sort by best match
    matches = sorted(matches, key=lambda x: x[0], reverse=True)
    return [m[1] for m in matches[:top_k]]

def respond(
    message,
    history: list[dict[str, str]],
    system_message,
    max_tokens,
    temperature,
    top_p,
    hf_token: gr.OAuthToken,
):
    client = InferenceClient(token=hf_token.token, model="openai/gpt-oss-20b")

    # Retrieve knowledge
    wiki_hits = search_wiki(message)
    if wiki_hits:
        knowledge_context = "\n".join(wiki_hits)
    else:
        knowledge_context = "No wiki info found. Answer simply without external info."

    messages = [
        {
            "role": "system",
            "content": (
                f"{system_message}\n\n"
                "You have access to the Clash Royale wiki database. "
                "Always use the following info if it is provided. "
                "Do not say 'I don’t know' if relevant info is present. "
                f"Knowledge:\n{knowledge_context}"
            ),
        }
    ]
    messages.extend(history)
    messages.append({"role": "user", "content": message})

    response = ""
    for message_chunk in client.chat_completion(
        messages,
        max_tokens=max_tokens,
        stream=True,
        temperature=temperature,
        top_p=top_p,
    ):
        choices = message_chunk.choices
        token = ""
        if len(choices) and choices[0].delta.content:
            token = choices[0].delta.content
        response += token
        yield response

chatbot = gr.ChatInterface(
    respond,
    type="messages",
    additional_inputs=[
        gr.Textbox(value=CLASH_ROYALE_SYSTEM_MESSAGE, label="System message"),
        gr.Slider(minimum=1, maximum=2048, value=1300, step=1, label="Max new tokens"),
        gr.Slider(minimum=0.1, maximum=4.0, value=0.7, step=0.1, label="Temperature"),
        gr.Slider(
            minimum=0.1,
            maximum=1.0,
            value=0.95,
            step=0.05,
            label="Top-p (nucleus sampling)",
        ),
    ],
)

with gr.Blocks() as demo:
    with gr.Sidebar():
        gr.LoginButton()
    chatbot.render()

if __name__ == "__main__":
    demo.launch()