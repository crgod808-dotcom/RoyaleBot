Clash Royale AI frontend (enhanced)

Files included: index.html, style.css, script.js, sw.js, manifest.json, icons

Copied from your HuggingFace Space repo:
 - RuleBook.py
 - clashinfo.py
 - clash_wiki_clean.csv
 - README.md
 - app.py
 - requirements.txt

Important: set HF_API_URL inside script.js to your HF Space predict endpoint or proxy.
